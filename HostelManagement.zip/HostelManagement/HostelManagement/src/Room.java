public class Room {

    String roomNo;
    String living;
    String studentName;

    // Constructor;
    public Room(String roomNo, String living, String allottedTo) {
        this.roomNo = roomNo;
        this.living = living;
        this.studentName = allottedTo;
    }
}
