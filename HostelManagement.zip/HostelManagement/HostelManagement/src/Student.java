public class Student {

    String studentName;
    String password;
    String roomNo;
    String fee;

    // Constructor
    public Student(String studentName, String password, String roomNo, String fee) {
        this.studentName = studentName;
        this.password = password;
        this.roomNo = roomNo;
        this.fee = fee;
    }
}
