public class Main {
    public static void main(String[] args) throws Exception {

        // Create login
        LoginGUI loginGUI = new LoginGUI();

        // Visible to it
        loginGUI.setVisible(true);
    }
}
