public class StudentsMessage {

    String student;
    String message;

    // Store data of student and the Request
    public StudentsMessage(String applicant, String message) {
        this.student = applicant;
        this.message = message;
    }
}
